#!/bin/bash
#BucketExplorer
BucketExplorer_home=$(cd $(dirname $0) && pwd)

chkpath="$BucketExplorer_home/jre/bin/java"
if [ -e $chkpath ]
then
export PATH=$BucketExplorer_home/jre/bin:${PATH}
export CLASSPATH=$BucketExplorer_home/BucketExplorer.jar:${CLASSPATH}
java -Xms512M -Xmx1G -XX:+UseG1GC -jar BucketExplorer.jar
else
echo "jre not found at Path $BucketExplorer_home."
echo "Copy jre folder at path $BucketExplorer_home."
fi

