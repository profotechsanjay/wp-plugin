#!/bin/bash
#BucketExplorer
BucketExplorer_home=$(cd $(dirname $0) && pwd)
if [ -e $BucketExplorer_home ]
then
export CLASSPATH=$BucketExplorer_home/BucketExplorer.jar:${CLASSPATH}
java -Xms512M -Xmx1G -XX:+UseG1GC -jar BucketExplorer.jar
else
echo "Path $BucketExplorer_home not found"
echo "Edit BucketExplorer_home to specify full PATH of Bucket Explorer home directory"
fi
